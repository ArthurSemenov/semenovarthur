document.querySelector('.header-burger').addEventListener('click', () => {
  document.querySelector('.primary-menu').classList.toggle('active');
});

document.querySelector('.header-burger-menu').addEventListener('click', () => {
  document.querySelector('.primary-menu').classList.toggle('active');
});
