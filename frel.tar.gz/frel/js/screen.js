$(document).ready(function () {
  $('.welcome-screen .owl-carousel').owlCarousel({
    items: 1,
    loop: true,
    margin: 60,
    nav: true,
    navText: ['', ''],
    touchDrag: false,
    mouseDrag: false,
  });

  $('.slide-controller .slide-prev').on('click', function () {
    $('.slide-controller .owl-nav .owl-prev').click();
  });
  $('.slide-controller .slide-next').on('click', function () {
    $('.slide-controller .owl-nav .owl-next').click();
  });
  $('.slide-controller .slide-prev, .slide-controller .slide-next').on('click', function () {
    $('.slide-controller .owl-carousel').find('.col').removeClass('active');
    $('.owl-item.active .item .col:eq(0)').addClass('active');
  });

  $('.slide-controller .slide-indicators .item .col').hover(function () {
    $(this).parents('.owl-carousel').find('.col').removeClass('active');
    $(this).addClass('active');
  });
  $('.fancybox-video').fancybox({
    helpers: {
      media: true,
    },
    youtube: {
      autoplay: 1,
    },
  });
  $('.what-say .owl-carousel').owlCarousel({
    loop: true,
    margin: 20,
    nav: true,
    navText: ['', ''],
    responsive: {
      0: {
        items: 1,
      },
      1200: {
        items: 2,
      },
    },
  });
  $('.partners-screen .owl-carousel').owlCarousel({
    loop: true,
    margin: 20,
    nav: true,
    navText: ['', ''],
    responsive: {
      0: {
        items: 1,
      },
      480: {
        items: 3,
      },
      1000: {
        items: 4,
      },
      1280: {
        items: 6,
      },
    },
  });
});
